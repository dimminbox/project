<?php
class AdminController extends Controller
{

    public $layout='//layouts/column2';



}