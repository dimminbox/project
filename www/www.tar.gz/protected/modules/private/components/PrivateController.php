<?php

class PrivateController extends Controller
{

    public $layout='//layouts/column2';


}