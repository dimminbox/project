<?php

/* @var $this PrivateController */
/* @var $model DepositForm */
/* @var $form ActiveForm */

$this->pageTitle=Yii::app()->name . ' - Пополнение счета';
$this->breadcrumbs=array(
    'Личный кабинет' => array('/private'),
    'Пополнение счета',
);
?>

    <h1>Пополнение счета</h1>
